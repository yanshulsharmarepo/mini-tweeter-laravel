<html>
<style>
    form {
        border: 3px solid #f1f1f1;
    }
    textarea {
        resize: none;
        display: block;
        margin-left: auto;
        margin-right: auto;
    }
    input[type=text], input[type=password] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        box-sizing: border-box;
    }

    button {
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
    }
    tr {
        display: table-cell;
        vertical-align: inherit;
        font-weight: bold;
        text-align: center;
    }
    button:hover {
        opacity: 0.8;
    }

    .cancelbtn {
        width: auto;
        padding: 10px 18px;
        background-color: #f44336;
    }

    .imgcontainer {
        text-align: center;
        margin: 24px 0 12px 0;
    }

    img.avatar {
        width: 40%;
        border-radius: 50%;
    }

    .container {
        padding: 16px;
    }

    span.psw {
        float: right;
        padding-top: 16px;
    }

    /* Change styles for span and cancel button on extra small screens */
    @media  screen and (max-width: 300px) {
        span.psw {
            display: block;
            float: none;
        }
        .cancelbtn {
            width: 100%;
        }
    }
    input[type=text] {
        width: 130px;
        box-sizing: border-box;
        border: 2px solid #ccc;
        border-radius: 4px;
        font-size: 16px;
        background-color: white;
        background-position: 10px 10px;
        background-repeat: no-repeat;
        padding: 12px 20px 12px 40px;
        -webkit-transition: width 0.4s ease-in-out;
        transition: width 0.4s ease-in-out;
    }

    input[type=text]:focus {
        width: 100%;
    }
</style>
<br>
<h1>Hello</h1>

<form action="/search">
    <input type="text" name="search" placeholder="Search..">
    <button type="submit">Submit</button>
</form>
<h2>start tweet</h2>

<form action="/tweetsave">
    <?php echo e(csrf_field()); ?>

    <div class="imgcontainer">
        <img src="http://127.0.0.1:8000/image/a.png" alt="Avatar" class="avatar" height="152" width="42">
    </div>

    <div class="container">
        <label><b>Tweet area</b></label>
        <textarea rows="4" cols="50" maxlength="140" name="tweet">
        </textarea>

        <button type="submit">Submit</button>
        <input type="checkbox" checked="checked">
    </div>
</form>
<h2>ALL tweet of your friend</h2>

        <?php for($i = 0; $i < $responce['count']; $i++): ?>
        <?php for($j = 0; $j < $responce['count1']; $j++): ?>

            <?php if((($responce['data'][$i]['name']==$responce['data1'][$j]['name1'])and (($responce['data1'][$j]['name']==$responce['name'])) )or (($responce['data'][$i]['name']==$responce['name']))): ?>
                <tr>
               <th> <textarea rows="4" cols="50" maxlength="140" readonly>
                       <?php echo e($responce['data'][$i]['tweet']); ?></textarea></th><th> <?php echo e($responce['data'][$i]['name']); ?>

                    </th></tr>
                <br>
                <?php break; ?>;
            <?php endif; ?>


        <?php endfor; ?>
        <?php endfor; ?>


<h2> Person who mentions you in their tweet</h2>
<?php for($i = 0; $i < $responce['count']; $i++): ?>
    <?php for($j = 0; $j < $responce['count2']; $j++): ?>

        <?php if(($responce['data'][$i]['msgid']==$responce['data2'][$j]['msgid'])and($responce['name']==$responce['data2'][$j]['name'])): ?>
            <tr>
                <th> <?php echo e($responce['data'][$i]['name']); ?></th>
                <th> <textarea rows="4" cols="50" maxlength="140" readonly>
                       <?php echo e($responce['data'][$i]['tweet']); ?></textarea></th>
                </tr>
            <?php break; ?>;
        <?php endif; ?>
        <?php endfor; ?>
        <?php endfor; ?>
</body>
</html>