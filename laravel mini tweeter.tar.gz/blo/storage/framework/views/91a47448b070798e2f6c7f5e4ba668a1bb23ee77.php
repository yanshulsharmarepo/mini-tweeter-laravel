
<?php for($i = 0; $i < $responce['count']; $i++): ?>
    <?php if($responce['users'][$i]['name']==$responce['search']): ?>
    <tr>
        <p><?php echo e($responce['users'][$i]['name']); ?></p>
        <a href= "http://127.0.0.1:8000/follow/<?php echo e($responce['users'][$i]['name']); ?>">follow</a>

    </tr>
    <br>
    <?php endif; ?>
<?php endfor; ?>
<a href="/tweetgo">go to tweet</a>