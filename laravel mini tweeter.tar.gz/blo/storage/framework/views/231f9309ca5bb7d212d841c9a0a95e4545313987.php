<html>
<body>

<h1>Hello</h1>

<p>This is user <?php echo e($responce['name']); ?></p>
</body>
</html>