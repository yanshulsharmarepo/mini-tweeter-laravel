<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 12/5/17
 * Time: 10:15 AM
 */
echo "hello";