<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 12/5/17
 * Time: 9:44 AM
 */
echo "apple";