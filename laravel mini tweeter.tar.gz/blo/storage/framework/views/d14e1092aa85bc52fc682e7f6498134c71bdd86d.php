<html>
<body>
<h1>Hello</h1>
<p>This is user <?php echo e($responce['name']); ?></p>
<p>This is user <?php echo e($responce['key']); ?></p>
<h2>Login Form</h2>

<form action="/action1">
    <?php echo e(csrf_field()); ?>

    <div class="imgcontainer">
        <img src="img_avatar2.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">

        <button type="submit">Login</button>
        <input type="checkbox" checked="checked"> Remember me
    </div>

    <div class="container" style="background-color:#f1f1f1">
        <button type="button" class="cancelbtn">Cancel</button>
        <span class="psw">Forgot <a href="#">password?</a></span>
    </div>
</form>
</body>
</html>