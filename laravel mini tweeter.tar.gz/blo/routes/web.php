<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
        //echo 'welcome';
});*/

/*Route::get('/', function () {
      $name=["yanshul","sri","rahul"];
   // return view('greeting',$name);
    return view('greeting')->with('name', $name);
   // return $view->with('count', $name);
});*/

/*Route::get('/', function () {
    $name=["yanshul","sri","rahul"];
    // return view('greeting',$name);
    return view('greeting')->with('name', $name);
    // return $view->with('count', $name);
});*/

Route::get('/', 'HomeController@show');
Route::get('/action', 'HomeController@show2');
Route::get('/action1', 'HomeController@show3');
Route::get('/action11', 'HomeController@login');
Route::get('/tweetsave', 'HomeController@tweetsave');
Route::get('/search', 'HomeController@search');
Route::get('/tweetgo', 'HomeController@tweetgo');

Route::get('/follow/{search}', 'HomeController@follow');


// route to show the login form
Route::get('auth/login', array('uses' => 'HomeController@showLogin'));

// route to process the form
Route::post('auth/login', array('uses' => 'HomeController@doLogin'));
/*Route::post('/action_php', function () {

    return view('auth/action_php');
});*/

Route::post('/action_php','con@show');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
