<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class twt extends Model
{
    //
    public $fillable = [
        'id', 'msgid', 'tweet',
    ];

    public $table = 'twt';
}
