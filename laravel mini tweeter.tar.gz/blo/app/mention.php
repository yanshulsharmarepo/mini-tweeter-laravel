<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mention extends Model
{
    //

    public $fillable = [
        'msgid', 'name',
    ];

    public $table = 'mentions';
    public $timestamps = false;
}
