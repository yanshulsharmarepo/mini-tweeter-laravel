<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class twte extends Model
{
    //
    public $fillable = [
         'msgid', 'name','tweet',
    ];

    public $table = 'twte';
}
