<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Http\Controllers\Controller;
class con extends Controller
{

    public function show(Request $request)
    {
        //return view('auth/action_php');
        /*Route::post('/action_php', function () {
      */
        //Session::set('uname', $name);
        //Session::set('pwd', $password);
        //$name = $request->session()->get('uname');
        //$password = $request->session()->get('pwd');
            return view('auth/action_php');
        //});
        //return $a+$b;
    }
}
