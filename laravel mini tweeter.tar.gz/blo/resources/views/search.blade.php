
@for ($i = 0; $i < $responce['count']; $i++)
    @if($responce['users'][$i]['name']==$responce['search'])
    <tr>
        <p>{{ $responce['users'][$i]['name'] }}</p>
        <a href= "http://127.0.0.1:8000/follow/{{ $responce['users'][$i]['name'] }}">follow</a>

    </tr>
    <br>
    @endif
@endfor
<a href="/tweetgo">go to tweet</a>