<?php
/**
 * Created by PhpStorm.
 * User: root
 * Date: 14/5/17
 * Time: 10:09 PM
 */
class UserTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('users')->delete();
        User::create(array(
            'name' => 'Chris Sevilleja',
            'username' => 'sevilayha',
            'email' => 'chris@scotch.io',
            'password' => Hash::make('awesome'),
        ));
    }
}